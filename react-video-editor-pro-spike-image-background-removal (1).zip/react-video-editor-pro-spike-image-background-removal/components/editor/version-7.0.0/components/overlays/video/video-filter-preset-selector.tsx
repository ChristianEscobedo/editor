/**
 * Re-export MediaFilterPresetSelector to maintain backward compatibility
 * @deprecated Use MediaFilterPresetSelector instead
 */
export { MediaFilterPresetSelector as VideoFilterPresetSelector } from "../common/media-filter-preset-selector";
