import { registerRoot } from "remotion";
import { RemotionRoot } from "./root";

registerRoot(RemotionRoot);
