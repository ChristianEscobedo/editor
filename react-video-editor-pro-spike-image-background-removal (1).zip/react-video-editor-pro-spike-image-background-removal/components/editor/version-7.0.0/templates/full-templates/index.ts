// Create this new file to export all templates
export const templateFiles = [
  "example-7.json",
  "example-5.json",
  "example-6.json",
  "example-1.json",
  "example-2.json",
  "example-3.json",
  // Add new templates here
] as const;
