---
version: "2.0.0"
date: "2024-09-01"
title: "Version 2.0.0"
description: "Enhanced video editing functionality and improved user experience."
changes:
  - "Added clip splitting, duplication, and deletion"
  - "Implemented context menu for quick actions"
  - "Refactored code into reusable components"
  - "Improved timeline accuracy and visual feedback"
status: "Archived"
branch: "-"
---
